TO RUN NaiveBayes:
Run: java NaiveBayes.java breast-cancer-training.csv breast-cancer-test.csv
Where arg1 is the training data file: breast-cancer-training.csv
Where arg2 is the test data file: breast-cancer-test.csv